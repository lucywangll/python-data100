"""A module with a command-line interface for validating zip submissions"""
